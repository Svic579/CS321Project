package com.example.epa;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.*;
import java.util.*;

public class GoogleMaps extends AppCompatActivity {
    ArrayList<String> info;

    String name;

    EditText nameinput;

    Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_maps);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        nameinput = (EditText) (findViewById(R.id.nameinput));

        submitButton = (Button) findViewById((R.id.submitButton));
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = nameinput.getText().toString();

                showToast(name);
            }
        });
    }

    private void showToast(String text) {
        Toast.makeText(GoogleMaps.this, text, Toast.LENGTH_SHORT).show();
    }

    public void read() {
        ArrayList<String> info = new ArrayList<String>();
        Scanner s;
        try{
            s = new Scanner(new File("in.txt")); //intializing scanner and opening the file for the first time
            while(s.hasNext()) { //ensuring the file has a next element
                s.useDelimiter("\n");
                info.add(s.next());
            } s.close(); }
        catch (FileNotFoundException e) {}
        catch (Exception e) {}
    }

}
