package com.example.epa;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.*;
import java.util.*;
import java.util.ArrayList;



//class Sheleter {
//    /** Shelters 10-digit phone number, if available.
//     * ex . 5719292929
//     * . if not is 0**/
//    int num;
//    /** The county the shelter is located in**/
//    String county;
//    /** The name of the shelter **/
//    String name;
//    /** The address of the shelter**/
//    String address;
//    /** The state the shelter is located in **/
//    String State = "VA"; //currently only returns VA
//                         // Could be used for scalability.
//    /** The latitude of the shelter **/
//    int lat;
//    /** The Longitude of the shelter **/
//    int lon;
//
//    public int getLat() { return lat; }
//    public void setLat(int lat) {
//        this.lat = lat;
//    }
//    public int getLon() {
//        return lon;
//    }
//    public void setLon(int lon) {
//        this.lon = lon;
//    }
//    public int getNum() {
//        return num;
//    }
//    public void setNum(int num) {
//        this.num = num;
//    }
//    public String getCounty() { return county; }
//    public void setCounty(String county) { this.county = county; }
//    public String getAddress() { return address; }
//    public void setAddress(String address) { this.address = address; }
//    public String getName() { return name; }
//    public void setName(String name) {this.name = name; }
//    public String getState() { return State; }
//    public void setState(String state) { State = state; }
//}



public class GoogleMaps extends AppCompatActivity {
    ArrayList<String> info;

    String name;
//    Sheleter S = new Sheleter();
    EditText nameinput;
    TextView textView;
    Button submitButton;
    final static int REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_maps);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        nameinput = (findViewById(R.id.nameinput));
        textView= findViewById(R.id.textView3);
        submitButton = findViewById((R.id.submitButton));
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = nameinput.getText().toString();

//                showToast(name);
                Intent intent = new Intent(GoogleMaps.this,MapsActivity.class);
                intent.putExtra("county", name);
                Context context = getApplicationContext();
                Toast.makeText(context,"" + name ,Toast.LENGTH_LONG).show();
                if(name.equalsIgnoreCase("Fairfax") || name.equalsIgnoreCase("Loudoun")) {
                    startActivityForResult(intent,REQUEST_CODE);
                    textView.setVisibility(View.INVISIBLE);
                }
                else{
                    textView.setVisibility(View.VISIBLE);
                }

            }
        });
    }


    private void showToast(String text) {
        Toast.makeText(GoogleMaps.this, text, Toast.LENGTH_SHORT).show();
    }

    public ArrayList<String> read() {
        ArrayList<String> info = new ArrayList<String>();
        Scanner s;
        try{
            s = new Scanner(new File("in.txt")); //initializing scanner and opening the file for the first time
            while(s.hasNext()) { //ensuring the file has a next element
                s.useDelimiter("\n");
                info.add(s.next());
            } s.close(); }
        catch (FileNotFoundException e) {}
        catch (Exception e) {}
        return info;
    }
    public ArrayList<List<String>> search(LatLng curr){
        ArrayList<String> Shelters = this.read();
        ArrayList<List<String>> ans = null;
        for(int i=0;i<Shelters.size();i++){
            List<String> t1 = Arrays.asList(Shelters.get(i).split("\\s*,\\s*"));
            if(name.toLowerCase() == t1.get(0).toLowerCase()){
                ans.add(t1);

            }
        }
        if(ans == null){
            return null;
        }
        return ans;
    }


}
