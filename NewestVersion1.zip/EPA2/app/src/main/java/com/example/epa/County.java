package com.example.epa;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class County extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_county);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    public ArrayList<String> read() {
        ArrayList<String> info = new ArrayList<String>();
        Scanner s;
        try{
            s = new Scanner(new File("in.txt.csv")); //intializing scanner and opening the file for the first time
            while(s.hasNext()) { //ensuring the file has a next element
                s.useDelimiter("\n");
                info.add(s.next());
            } s.close(); }
        catch (FileNotFoundException e) {}
        catch (Exception e) {}

        return info;
    }

    public String find(String name) {
        String s = "";
        int counter = 0;
        ArrayList<String> list = read();
        for (String shelter: list) {
            if (counter == name.length()) {
                counter = 0;
                s += (shelter + "\n");
            }
        }
        return s;
    }

    //if s == "", Invalid county!
}
