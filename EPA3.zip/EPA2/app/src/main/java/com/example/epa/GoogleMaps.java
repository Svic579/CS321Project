package com.example.epa;

import android.os.Bundle;


import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
//import androidx.fragment.app.FragmentActivity;

import java.io.File;
import java.io.*;
import java.util.*;



import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

//import android.os.Bundle;
//import android.support.v7.app.AppCompatActivity;

import android.view.View;
import android.widget.EditText;
//import com.google.android.gms.maps.GoogleMap;




public class GoogleMaps extends AppCompatActivity {
    implements OnMapReadyCallback{

    EditText t1;
    String t2;
    MapFragment mapFragment = (MapFragment) getFragmentManager()
            .findFragmentById(R.id.map);
    mapFragment.getMapAsync(this);

    @Override
    public void onMapReady(GoogleMap map) {
        map.addMarker(new MarkerOptions()
                .position(new LatLng(0, 0))
                .title("Marker"));
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_maps);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
//        t1 =  (EditText)findViewById(R.id.textView1);
//        t1.getText().toString();
    }
//    public static void read(String file){
//        try{
//            FileReader f = new FileReader(file);
//
//            CSVReader csvReader = new CSVReader(f);
//            String[] next;
//            while(next = csvReader.readNext()!=null){
//                for(String cell : nextRecord){
//                    System.out.print(cell + "\t");
//                }
//                System.out.println();
//            }
//        }
//        catch(Exception e){
//            e.printStackTrace();
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }
//    }
public ArrayList<String> read() {
    ArrayList<String> info = new ArrayList<String>();
    Scanner s;
    try{
        s = new Scanner(new File("List.csv")); //intializing scanner and opening the file for the first time
        while(s.hasNext()) { //ensuring the file has a next element
            s.useDelimiter("\n");
            info.add(s.next());
        } s.close(); }
    catch (FileNotFoundException e) {}
    catch (Exception e) {}
    System.out.println(info);
    return info;
}



    public static void main(String args[]){
//        GoogleMaps G2 = new GoogleMaps();

    }





}
