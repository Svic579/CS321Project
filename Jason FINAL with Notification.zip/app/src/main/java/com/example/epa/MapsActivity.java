package com.example.epa;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import static android.telephony.CellLocation.requestLocationUpdate;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    LatLng curr = new LatLng(38.834721, -77.312683);
    String county;
    Double longitude, latitude;
    Context context;
    ArrayList<String[]> Shelters = new ArrayList<>();

    private void init() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.MAPS_RECEIVE)
                == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED) {
            requestLocationUpdate();
            Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            longitude = location.getLongitude();
            latitude = location.getLatitude();
            curr = new LatLng(longitude, latitude);
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        context = getApplicationContext();
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.INTERNET, Manifest.permission.INTERNET}, 200);
        county = getIntent().getExtras().getString("county");

    }

    public ArrayList<String[]> r() {
        String lists =
                "Good Shepherd Alliance,Loudoun, 20684 Ashburn Rd, Ashburn, VA 20147,(703) 724-1555,39.04525,-77.4866\n" +
                        "Loudoun County Youth Shelter,Loudoun,16450 Meadowview Ct, Leesburg, VA 20175,(703) 771-5300,39.078049,-77.550217\n" +
                        "Cold Weather Shelter,Loudoun,19520 Meadowview Court, Leesburg, VA 20175,(571) 258-3033,39.07682,-77.5499\n" +
                        "Loudoun Homeless Shelter,Loudoun,16400 Meadowview Ct, Leesburg, VA 20175,(703 777-0420,39.07619,-77.54998\n" +
                        "Louduon County Family Services Department,Loudoun,102 Heritage Way NE # 103, Leesburg, VA 20176,(703) 777-0353,39.11441,-77.54058\n" +
                        "Bailey's Crossroads Community Shelter ,Fairfax,3525 Moncure Ave ,Falls Church, VA,(703) 820-7621,38.84779,-77.13296\n" +
                        "Katherine Hanley Family Shelter,Fairfax,12970 Katherine Hanley Court, Fairfax, VA 22030,(571) 522-6800,38.8416,-77.39511\n" +
                        "Embry Rucker Community Shelter ,Fairfax, 11975 Bowman Towne Drive, Reston, VA 20190,(703) 437-1975,38.96159,-77.35991\n" +
                        "Patrick Henery Family Shelter,Fairfax,3080 Patrick Henry Drive, Falls Church, VA 22044,(703) 536-2155,38.86616,-77.15049\n" +
                        "Eleanor U. Kennedy Shelter,Fairfax,9155 Richmond Highway, Fort Belvoir, VA 22060,(703) 799-0200,38.96159,-77.35991\n" +
                        "Embry Rucker Community Shelter,Fairfax,11975 Bowman Towne Drive, Reston, VA 20190,(703) 437-1975,38.96159,-77.359909";

        for (int i = 0; i < lists.split("\n").length; i++) {
            String[] b = lists.split("\n")[i].split(",");
            Shelters.add(b);
        }
        return Shelters;
    }


//    public Location getLocation() {
//
//        LocationManager lm1 = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
//        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            Toast.makeText(context, "Permission NOT Granted!", Toast.LENGTH_SHORT).show();
//            Location l = lm1.getLastKnownLocation(LocationManager.GPS_PROVIDER);
//            Toast.makeText(context, "L = " + l.getLongitude(), Toast.LENGTH_LONG).show();
//            return l;
//        }
//        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
//        boolean isGPSEnabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
//        if (isGPSEnabled) {
//            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 6000, 10, (LocationListener) this);
//            Location l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
//            return l;
//        } else {
//            Toast.makeText(context, "Please Enable GPS", Toast.LENGTH_LONG).show();
//        }
//        Location l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
//        return l;
//    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.moveCamera(CameraUpdateFactory.newLatLng(curr));
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(curr, 8), 5000, null);
        mMap.addMarker(new MarkerOptions().position(curr).title("Current Location"));
//        LocationManager lm = (LocationManager) context.getSystemService(context.LOCATION_SERVICE);
//        @SuppressLint("MissingPermission") Location l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
//        LatLng test = new LatLng(l.getLatitude(), l.getLongitude());
//        mMap.addMarker(new MarkerOptions().position(test).title("Physical Location"));
        init();
        r();
        for (int i = 0; i < Shelters.size() - 1; i++) {
            if (Shelters.get(i)[1].equalsIgnoreCase(county)) {
                double Lat = Double.parseDouble(Shelters.get(i)[6]);
                double Lng = Double.parseDouble(Shelters.get(i)[7]);
                LatLng Shelter = new LatLng(Lat, Lng);
                mMap.addMarker(new MarkerOptions().position(Shelter).title("Shelter"));
            }
        }
    }
}