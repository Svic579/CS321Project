package com.example.epa;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;

public class Specific extends AppCompatActivity {
    private Button fire,tornado,flood,quake;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specific);
//        Toolbar toolbar = findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);
//
//        FloatingActionButton fab = findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

        fire = findViewById(R.id.fire);
        fire.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(Specific.this,Fire.class);
                startActivity(intent);
            }
        });
        tornado = findViewById(R.id.tornado);
        tornado.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(Specific.this,Tornado.class);
                startActivity(intent);
            }
        });
        flood = findViewById(R.id.flood);
        flood.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent (Specific.this,Flood.class);
                startActivity(intent);
            }
        });
        quake = findViewById(R.id.quake);
        quake.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent (Specific.this,Earthquake.class);
                startActivity(intent);
            }
        });
    }

}
